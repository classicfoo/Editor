using System;
using System.Windows.Forms;
using System.IO;
using System.Drawing;
using System.Runtime.InteropServices;

public class TestClass : Form
{
	public int LineNum;
		
	public TestClass()
	{
	
		
		
	}
	
}

