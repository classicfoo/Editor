convert 16.png 32.png 48.png -colors 256 icon.ico
