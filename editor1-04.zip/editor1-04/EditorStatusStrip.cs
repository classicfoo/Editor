using System;
using System.Windows.Forms;
using System.IO;
using System.Drawing;

public class EditorStatusStrip : StatusStrip
{
	
}