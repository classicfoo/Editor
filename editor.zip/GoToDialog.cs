using System;
using System.Windows.Forms;

public class GoToDialog : PromptDialog
{
	public GoToDialog()
	{
		this.Text = "Go To Line";
		this.label.Text = "Line Number";
	}
	
	
	
}