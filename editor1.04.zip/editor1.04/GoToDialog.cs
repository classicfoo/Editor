using System;
using System.Windows.Forms;
using System.Drawing;

public class GoToDialog : PromptDialog
{
	public GoToDialog()
	{
		
		this.Text = "Go To Line";		
		this.Width = 200;

		this.label.Text = "Line Number:";

		tb.Width = 160;
	}
	
	
	
}
